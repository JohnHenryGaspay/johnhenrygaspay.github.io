# [Start Bootstrap - Bare](https://startbootstrap.com/template/bare/)

## Preview

[![Bare Preview](https://johnhenrygaspay.github.io/test-project/images/bare.jpg)]

**[View Live Preview](https://johnhenrygaspay.github.io/test-project/index.html)**

 
Copyright 2013-2020 Start Bootstrap LLC. Code released under the [MIT](https://github.com/StartBootstrap/startbootstrap-bare/blob/master/LICENSE) license.
